using Microsoft.EntityFrameworkCore;
using OnlineLearningPlatform.Data;
using OnlineLearningPlatform.Entities;
using OnlineLearningPlatform.Enums;

namespace OnlineLearningPlatform
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using var context = new AppDbContext();

            SeedStudentsAndEnrollments(context);

            Console.WriteLine("=== CREATE OPERATIONS ===");
            AddInstructor(context, "Khaled Nabil", "khaled@platform.com", "Database Expert");
            AddCourse(context, "Entity Framework Core Mastery", "Deep dive into EF Core", 65.00m, CourseLevel.Intermediate, instructorId: 1, categoryId: 5);
            AddCourse(context, "Invalid Course", null, 10m, CourseLevel.Beginner, instructorId: 999, categoryId: 5);
            AddThreeStudents(context);
            EnrollStudent(context, studentId: 1, courseId: 4);
            EnrollStudent(context, studentId: 1, courseId: 5);
            EnrollStudent(context, studentId: 1, courseId: 1);

            Console.WriteLine("\n=== READ OPERATIONS ===");
            FindCourse(context, id: 2, title: "React Complete Guide");
            FindCourse(context, id: 999, title: "Non Existent Course");
            FilterCoursesByPrice(context, minPrice: 30m, maxPrice: 90m);
            PrintCategoriesHierarchy(context, parentCategoryId: 1);
            PrintCourseRoster(context, courseId: 1);

            Console.WriteLine("\n=== UPDATE OPERATIONS ===");
            ChangeCoursePrice(context, courseId: 1, newPrice: 39.99m);
            UpdateEnrollmentProgress(context, studentId: 1, courseId: 1, newProgress: 100);
            UpdateEnrollmentProgress(context, studentId: 1, courseId: 1, newProgress: 150);
            PublishCourse(context, courseId: 5);

            Console.WriteLine("\n=== DELETE OPERATIONS ===");
            UnenrollStudent(context, studentId: 2, courseId: 2);
            DeleteCategoryUnsafeThenSafe(context, categoryId: 1);
            DeleteCourseWithEnrollments(context, courseId: 3);

            Console.WriteLine("\n=== BULK OPERATIONS ===");
            BulkRaisePrice(context, CourseLevel.Intermediate);
            BulkDeleteDroppedEnrollments(context);
        }

        static void SeedStudentsAndEnrollments(AppDbContext context)
        {
            if (!context.Students.Any())
            {
                var students = new List<Student>
                {
                    new Student { FullName = "Mohanned Mohamed", Email = "mohanned@student.com", DateOfBirth = new DateTime(2007, 5, 10) },
                    new Student { FullName = "Youssef Ali", Email = "youssef@student.com", DateOfBirth = new DateTime(2005, 8, 22) },
                    new Student { FullName = "Mariam Adel", Email = "mariam@student.com", DateOfBirth = new DateTime(2006, 2, 14) },
                    new Student { FullName = "Nourhan Samy", Email = "nourhan@student.com", DateOfBirth = new DateTime(2004, 11, 3) },
                    new Student { FullName = "Ziad Hossam", Email = "ziad@student.com", DateOfBirth = new DateTime(2006, 7, 19) }
                };
                context.Students.AddRange(students);
                context.SaveChanges();
                Console.WriteLine("Seeded 5 students.");
            }

            if (!context.Enrollments.Any())
            {
                var enrollments = new List<Enrollment>
                {
                    new Enrollment { StudentId = 1, CourseId = 1, EnrollmentDate = DateTime.Now.AddDays(-30), ProgressPercentage = 75, Status = EnrollmentStatus.Active },
                    new Enrollment { StudentId = 1, CourseId = 2, EnrollmentDate = DateTime.Now.AddDays(-20), ProgressPercentage = 100, Status = EnrollmentStatus.Completed, FinalGrade = 95.5m },
                    new Enrollment { StudentId = 2, CourseId = 1, EnrollmentDate = DateTime.Now.AddDays(-25), ProgressPercentage = 40, Status = EnrollmentStatus.Active },
                    new Enrollment { StudentId = 2, CourseId = 2, EnrollmentDate = DateTime.Now.AddDays(-15), ProgressPercentage = 10, Status = EnrollmentStatus.Dropped },
                    new Enrollment { StudentId = 3, CourseId = 3, EnrollmentDate = DateTime.Now.AddDays(-40), ProgressPercentage = 100, Status = EnrollmentStatus.Completed, FinalGrade = 88.0m },
                    new Enrollment { StudentId = 3, CourseId = 1, EnrollmentDate = DateTime.Now.AddDays(-10), ProgressPercentage = 20, Status = EnrollmentStatus.Active },
                    new Enrollment { StudentId = 4, CourseId = 3, EnrollmentDate = DateTime.Now.AddDays(-12), ProgressPercentage = 5, Status = EnrollmentStatus.Dropped },
                    new Enrollment { StudentId = 5, CourseId = 4, EnrollmentDate = DateTime.Now.AddDays(-5), ProgressPercentage = 60, Status = EnrollmentStatus.Active }
                };
                context.Enrollments.AddRange(enrollments);
                context.SaveChanges();
                Console.WriteLine("Seeded 8 enrollments.");
            }
        }

        static void AddInstructor(AppDbContext context, string fullName, string email, string? bio)
        {
            var instructor = new Instructor
            {
                FullName = fullName,
                Email = email,
                Bio = bio,
                JoinedDate = DateTime.Now
            };
            context.Instructors.Add(instructor);
            context.SaveChanges();
            Console.WriteLine($"[AddInstructor] Added '{instructor.FullName}' with Id = {instructor.Id}");
        }

        static void AddCourse(AppDbContext context, string title, string? desc, decimal price, CourseLevel level, int instructorId, int categoryId)
        {
            bool instructorExists = context.Instructors.Any(i => i.Id == instructorId);
            bool categoryExists = context.Categories.Any(c => c.Id == categoryId);

            if (!instructorExists || !categoryExists)
            {
                Console.WriteLine($"[AddCourse] Refused: Instructor (Id:{instructorId}) or Category (Id:{categoryId}) does not exist.");
                return;
            }

            var course = new Course
            {
                Title = title,
                Description = desc,
                Price = price,
                Level = level,
                IsPublished = false,
                InstructorId = instructorId,
                CategoryId = categoryId
            };
            context.Courses.Add(course);
            context.SaveChanges();
            Console.WriteLine($"[AddCourse] Added '{course.Title}' with Id = {course.Id}");
        }

        static void AddThreeStudents(AppDbContext context)
        {
            var newStudents = new List<Student>
            {
                new Student { FullName = "Kareem Mahmoud", Email = "kareem@student.com", DateOfBirth = new DateTime(2005, 1, 1) },
                new Student { FullName = "Salma Tarek", Email = "salma@student.com", DateOfBirth = new DateTime(2006, 3, 15) },
                new Student { FullName = "Mostafa Adel", Email = "mostafa@student.com", DateOfBirth = new DateTime(2004, 9, 20) }
            };

            context.Students.AddRange(newStudents);
            context.SaveChanges();

            Console.WriteLine($"[AddThreeStudents] Generated Ids: {string.Join(", ", newStudents.Select(s => s.Id))}");
        }

        static void EnrollStudent(AppDbContext context, int studentId, int courseId)
        {
            var studentExists = context.Students.Any(s => s.Id == studentId);
            if (!studentExists)
            {
                Console.WriteLine($"[EnrollStudent] Refused: Student {studentId} not found.");
                return;
            }

            var course = context.Courses.Find(courseId);
            if (course == null)
            {
                Console.WriteLine($"[EnrollStudent] Refused: Course {courseId} not found.");
                return;
            }

            if (!course.IsPublished)
            {
                Console.WriteLine($"[EnrollStudent] Refused: Course '{course.Title}' is not published yet.");
                return;
            }

            bool alreadyEnrolled = context.Enrollments.Any(e => e.StudentId == studentId && e.CourseId == courseId);
            if (alreadyEnrolled)
            {
                Console.WriteLine($"[EnrollStudent] Refused: Student {studentId} is already enrolled in Course {courseId}.");
                return;
            }

            var enrollment = new Enrollment
            {
                StudentId = studentId,
                CourseId = courseId,
                EnrollmentDate = DateTime.Now,
                ProgressPercentage = 0,
                Status = EnrollmentStatus.Active
            };
            context.Enrollments.Add(enrollment);
            context.SaveChanges();
            Console.WriteLine($"[EnrollStudent] Student {studentId} successfully enrolled in Course {courseId}.");
        }

        static void FindCourse(AppDbContext context, int id, string title)
        {
            var byId = context.Courses.Find(id);
            Console.WriteLine(byId != null
                ? $"[Find by Id {id}] Found: {byId.Title}"
                : $"[Find by Id {id}] not found");

            var byTitle = context.Courses.FirstOrDefault(c => c.Title == title);
            Console.WriteLine(byTitle != null
                ? $"[FirstOrDefault '{title}'] Found Id: {byTitle.Id}"
                : $"[FirstOrDefault '{title}'] not found");
        }

        static void FilterCoursesByPrice(AppDbContext context, decimal minPrice, decimal maxPrice)
        {
            var filtered = context.Courses
                .Where(c => c.Price >= minPrice && c.Price <= maxPrice)
                .OrderByDescending(c => c.Price)
                .Select(c => new { c.Title, c.Level, c.Price })
                .ToList();

            Console.WriteLine($"[FilterCourses {minPrice} - {maxPrice}]:");
            foreach (var c in filtered)
            {
                Console.WriteLine($"  - {c.Title} | {c.Level} | ${c.Price}");
            }
        }

        static void PrintCategoriesHierarchy(AppDbContext context, int parentCategoryId)
        {
            var subCategories = context.Categories
                .Where(c => c.ParentCategoryId == parentCategoryId)
                .Select(c => c.Name)
                .ToList();

            Console.WriteLine($"[Sub-categories of Category {parentCategoryId}]: {string.Join(", ", subCategories)}");

            var topLevel = context.Categories
                .Where(c => c.ParentCategoryId == null)
                .Select(c => c.Name)
                .ToList();

            Console.WriteLine($"[Top-level categories]: {string.Join(", ", topLevel)}");
        }

        static void PrintCourseRoster(AppDbContext context, int courseId)
        {
            var studentIds = context.Enrollments
                .Where(e => e.CourseId == courseId)
                .Select(e => e.StudentId)
                .ToList();

            var studentNames = context.Students
                .Where(s => studentIds.Contains(s.Id))
                .Select(s => s.FullName)
                .ToList();

            Console.WriteLine($"[Course {courseId} Roster] Total Enrolled: {studentNames.Count} -> {string.Join(", ", studentNames)}");
        }

        static void ChangeCoursePrice(AppDbContext context, int courseId, decimal newPrice)
        {
            var course = context.Courses.Find(courseId);
            if (course == null)
            {
                Console.WriteLine($"[ChangeCoursePrice] Course {courseId} not found.");
                return;
            }

            course.Price = newPrice;
            context.SaveChanges();
            Console.WriteLine($"[ChangeCoursePrice] Course '{course.Title}' price updated to ${newPrice}.");
        }

        static void UpdateEnrollmentProgress(AppDbContext context, int studentId, int courseId, int newProgress)
        {
            if (newProgress < 0 || newProgress > 100)
            {
                Console.WriteLine($"[UpdateProgress] Invalid progress ({newProgress}). Must be between 0 and 100.");
                return;
            }

            var enrollment = context.Enrollments.Find(studentId, courseId);
            if (enrollment == null)
            {
                Console.WriteLine($"[UpdateProgress] Enrollment not found for Student {studentId} in Course {courseId}.");
                return;
            }

            enrollment.ProgressPercentage = newProgress;
            if (newProgress == 100)
            {
                enrollment.Status = EnrollmentStatus.Completed;
            }

            context.SaveChanges();
            Console.WriteLine($"[UpdateProgress] Updated to {newProgress}%. Status: {enrollment.Status}");
        }

        static void PublishCourse(AppDbContext context, int courseId)
        {
            var course = context.Courses.Find(courseId);
            if (course == null)
            {
                Console.WriteLine($"[PublishCourse] Course {courseId} not found.");
                return;
            }

            course.IsPublished = true;
            course.PublishedDate = DateTime.Now;
            context.SaveChanges();
            Console.WriteLine($"[PublishCourse] '{course.Title}' is now published on {course.PublishedDate}.");
        }

        static void UnenrollStudent(AppDbContext context, int studentId, int courseId)
        {
            var enrollment = context.Enrollments.Find(studentId, courseId);
            if (enrollment == null)
            {
                Console.WriteLine($"[Unenroll] Enrollment not found.");
                return;
            }

            context.Enrollments.Remove(enrollment);
            context.SaveChanges();
            Console.WriteLine($"[Unenroll] Student {studentId} unenrolled from Course {courseId}.");
        }

        static void DeleteCategoryUnsafeThenSafe(AppDbContext context, int categoryId)
        {
            var category = context.Categories.Find(categoryId);
            if (category == null)
            {
                Console.WriteLine($"[DeleteCategory] Category {categoryId} not found.");
                return;
            }

            try
            {
                context.Categories.Remove(category);
                context.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                Console.WriteLine($"[DeleteCategory - Caught DbUpdateException]: {ex.InnerException?.Message ?? ex.Message}");
                context.Entry(category).State = EntityState.Unchanged;
            }

            bool hasSubCategories = context.Categories.Any(c => c.ParentCategoryId == categoryId);
            if (hasSubCategories)
            {
                Console.WriteLine($"[DeleteCategory - Safe Check]: Cannot delete Category '{category.Name}' because it still has sub-categories.");
                return;
            }

            context.Categories.Remove(category);
            context.SaveChanges();
            Console.WriteLine($"[DeleteCategory] Category '{category.Name}' deleted safely.");
        }

        static void DeleteCourseWithEnrollments(AppDbContext context, int courseId)
        {
            var course = context.Courses.Find(courseId);
            if (course == null)
            {
                Console.WriteLine($"[DeleteCourse] Course {courseId} not found.");
                return;
            }

            int beforeCount = context.Enrollments.Count(e => e.CourseId == courseId);
            Console.WriteLine($"[DeleteCourse] Enrollments count BEFORE deleting Course {courseId}: {beforeCount}");

            context.Courses.Remove(course);
            context.SaveChanges();

            int afterCount = context.Enrollments.Count(e => e.CourseId == courseId);
            Console.WriteLine($"[DeleteCourse] Enrollments count AFTER deleting Course {courseId}: {afterCount}");
        }

        static void BulkRaisePrice(AppDbContext context, CourseLevel level)
        {
            int affectedRows = context.Courses
                .Where(c => c.IsPublished && c.Level == level)
                .ExecuteUpdate(setters => setters
                    .SetProperty(c => c.Price, c => c.Price * 1.10m));

            Console.WriteLine($"[BulkRaisePrice] Raised price by 10% for {affectedRows} published {level} courses.");
        }

        static void BulkDeleteDroppedEnrollments(AppDbContext context)
        {
            int affectedRows = context.Enrollments
                .Where(e => e.Status == EnrollmentStatus.Dropped)
                .ExecuteDelete();

            Console.WriteLine($"[BulkDelete] Deleted {affectedRows} Dropped enrollments.");
        }
    }
}
