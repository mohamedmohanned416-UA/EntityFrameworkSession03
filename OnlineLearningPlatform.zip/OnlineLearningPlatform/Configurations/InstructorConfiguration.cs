using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OnlineLearningPlatform.Entities;

namespace OnlineLearningPlatform.Configurations
{
    public class InstructorConfiguration : IEntityTypeConfiguration<Instructor>
    {
        public void Configure(EntityTypeBuilder<Instructor> builder)
        {
            builder.HasKey(i => i.Id);

            builder.Property(i => i.FullName)
                   .IsRequired()
                   .HasMaxLength(150);

            builder.Property(i => i.Email)
                   .IsRequired()
                   .HasMaxLength(150);

            builder.Property(i => i.Bio)
                   .HasMaxLength(500);

            builder.Property(i => i.JoinedDate)
                   .IsRequired();

            builder.HasData(
                new Instructor { Id = 1, FullName = "Ahmed Tarek", Email = "ahmed.tarek@platform.com", Bio = "Senior Backend Engineer", JoinedDate = new DateTime(2023, 1, 15) },
                new Instructor { Id = 2, FullName = "Sara Mahmoud", Email = "sara.mahmoud@platform.com", Bio = "Frontend & UI/UX Architect", JoinedDate = new DateTime(2023, 5, 20) },
                new Instructor { Id = 3, FullName = "Omar Hassan", Email = "omar.hassan@platform.com", Bio = "Cloud & DevOps Specialist", JoinedDate = new DateTime(2024, 2, 10) }
            );
        }
    }
}
