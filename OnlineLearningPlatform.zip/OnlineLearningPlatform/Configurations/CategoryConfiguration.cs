using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OnlineLearningPlatform.Entities;

namespace OnlineLearningPlatform.Configurations
{
    public class CategoryConfiguration : IEntityTypeConfiguration<Category>
    {
        public void Configure(EntityTypeBuilder<Category> builder)
        {
            builder.HasKey(c => c.Id);

            builder.Property(c => c.Name)
                   .IsRequired()
                   .HasMaxLength(100);

            builder.Property(c => c.Description)
                   .HasMaxLength(300);

            builder.HasOne(c => c.ParentCategory)
                   .WithMany(c => c.SubCategories)
                   .HasForeignKey(c => c.ParentCategoryId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasData(
                new Category { Id = 1, Name = "Programming", Description = "All software development topics", ParentCategoryId = null },
                new Category { Id = 2, Name = "Cloud & DevOps", Description = "Cloud infrastructure and CI/CD", ParentCategoryId = null },
                new Category { Id = 3, Name = "Backend Development", Description = "Server-side technologies", ParentCategoryId = 1 },
                new Category { Id = 4, Name = "Frontend Development", Description = "Client-side web technologies", ParentCategoryId = 1 },
                new Category { Id = 5, Name = "ASP.NET Core", Description = "Microsoft C# web framework", ParentCategoryId = 3 },
                new Category { Id = 6, Name = "React", Description = "JavaScript UI library", ParentCategoryId = 4 }
            );
        }
    }
}
