using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OnlineLearningPlatform.Entities;
using OnlineLearningPlatform.Enums;

namespace OnlineLearningPlatform.Configurations
{
    public class CourseConfiguration : IEntityTypeConfiguration<Course>
    {
        public void Configure(EntityTypeBuilder<Course> builder)
        {
            builder.HasKey(c => c.Id);

            builder.Property(c => c.Title)
                   .IsRequired()
                   .HasMaxLength(200);

            builder.Property(c => c.Description)
                   .HasMaxLength(1000);

            builder.Property(c => c.Price)
                   .HasPrecision(10, 2);

            builder.Property(c => c.Level)
                   .IsRequired();

            builder.Property(c => c.IsPublished)
                   .IsRequired();

            builder.HasOne(c => c.Instructor)
                   .WithMany(i => i.Courses)
                   .HasForeignKey(c => c.InstructorId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasOne(c => c.Category)
                   .WithMany(cat => cat.Courses)
                   .HasForeignKey(c => c.CategoryId)
                   .OnDelete(DeleteBehavior.Restrict);

            builder.HasData(
                new Course { Id = 1, Title = "C# Fundamentals", Description = "Learn C# from scratch", Price = 29.99m, Level = CourseLevel.Beginner, IsPublished = true, PublishedDate = new DateTime(2024, 3, 1), InstructorId = 1, CategoryId = 3 },
                new Course { Id = 2, Title = "ASP.NET Core Web APIs", Description = "Build RESTful APIs", Price = 79.99m, Level = CourseLevel.Intermediate, IsPublished = true, PublishedDate = new DateTime(2024, 4, 15), InstructorId = 1, CategoryId = 5 },
                new Course { Id = 3, Title = "React Complete Guide", Description = "Modern React with Hooks", Price = 59.99m, Level = CourseLevel.Beginner, IsPublished = true, PublishedDate = new DateTime(2024, 5, 10), InstructorId = 2, CategoryId = 6 },
                new Course { Id = 4, Title = "Advanced Microservices", Description = "Distributed systems in .NET", Price = 120.00m, Level = CourseLevel.Advanced, IsPublished = true, PublishedDate = new DateTime(2024, 6, 1), InstructorId = 1, CategoryId = 5 },
                new Course { Id = 5, Title = "Docker & Kubernetes", Description = "Containerization mastery", Price = 89.50m, Level = CourseLevel.Intermediate, IsPublished = false, PublishedDate = null, InstructorId = 3, CategoryId = 2 },
                new Course { Id = 6, Title = "Advanced CSS & Animations", Description = "Deep dive into CSS Grid & Flexbox", Price = 45.00m, Level = CourseLevel.Advanced, IsPublished = false, PublishedDate = null, InstructorId = 2, CategoryId = 4 }
            );
        }
    }
}
