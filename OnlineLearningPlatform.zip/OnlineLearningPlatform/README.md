# Online Learning Platform - EF Core Assignment 03

Console application built with C#, Entity Framework Core (Code-First), and SQL Server demonstrating Many-to-Many relationships, Self-Referencing hierarchies, Fluent API configurations, Data Seeding, CRUD operations, and Bulk operations.

## Setup & Migrations

1. Update the connection string in `Data/AppDbContext.cs` if needed.
2. Run the following commands in Package Manager Console:

```powershell
Update-Database
```
